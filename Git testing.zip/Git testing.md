```python
import matplotlib.pyplot as plt
import pandas as pd
tendulkar=pd.read_csv('tendulkar1.csv',encoding="ISO-8859-1")
plt.scatter(tendulkar.BF,tendulkar.Runs)
```




    <matplotlib.collections.PathCollection at 0x234a45f6970>




![png](output_0_1.png)



```python

```
